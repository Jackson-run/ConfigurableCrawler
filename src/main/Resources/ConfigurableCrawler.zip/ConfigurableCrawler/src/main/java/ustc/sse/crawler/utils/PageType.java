package ustc.sse.crawler.utils;

/**
 * 爬取页面的分类
 *
 * @author wangrun
 * @version 0.1
 */
public enum PageType {
    /**
     * 静态页面
     */
    STATIC;
}
